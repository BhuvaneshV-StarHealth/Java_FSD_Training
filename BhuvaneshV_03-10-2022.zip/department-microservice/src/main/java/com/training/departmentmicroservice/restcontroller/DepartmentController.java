package com.training.departmentmicroservice.restcontroller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.training.departmentmicroservice.entity.Department;
import com.training.departmentmicroservice.service.IDepartmentService;

@RestController
@RequestMapping("/api/department")
public class DepartmentController {
	@Autowired
	IDepartmentService service;
	
	@PostMapping("/add")
	public Department addDepartment(@RequestBody Department dept) {
		return service.addDepartment(dept);
	}
	
	@GetMapping("/get/{id}")
	public Department getDepartmentById(Long id) {
		return service.getDepartmentById(id);
	}
}
