package com.training.departmentmicroservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.departmentmicroservice.entity.Department;
import com.training.departmentmicroservice.repo.IDepartmentRepo;

@Service
public class DepartmentServiceImp implements IDepartmentService {

	@Autowired
	IDepartmentRepo repo;
	@Override
	public Department addDepartment(Department dept) {
		// TODO Auto-generated method stub
		return repo.save(dept);
	}

	@Override
	public Department getDepartmentById(Long id) {
		// TODO Auto-generated method stub
		return repo.findById(id).orElse(new Department());
	}

}
