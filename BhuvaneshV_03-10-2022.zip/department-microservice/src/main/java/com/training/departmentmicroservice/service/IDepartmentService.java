package com.training.departmentmicroservice.service;

import com.training.departmentmicroservice.entity.Department;

public interface IDepartmentService {

	public Department addDepartment(Department dept);
	public Department getDepartmentById(Long id);
}
