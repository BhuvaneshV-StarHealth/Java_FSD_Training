package com.training.usermicroservice.service;

import com.training.usermicroservice.entity.User;
import com.training.usermicroservice.vo.UserDepartmentVO;

public interface IUserService {
	
	public User addUser(User user);
	public User getUserById(Long userId);
	public UserDepartmentVO getUserWithDept(Long userId);

}
