package com.training.usermicroservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.training.usermicroservice.entity.User;
import com.training.usermicroservice.repository.UserRepository;
import com.training.usermicroservice.vo.UserDepartmentVO;

@Service
public class Userservice implements IUserService {

	@Autowired
	RestTemplate restTemplate;
	@Autowired
	UserRepository repo;
	@Override
	public User addUser(User user) {
		// TODO Auto-generated method stub
		return repo.save(user);
	}

	@Override
	public User getUserById(Long userId) {
		// TODO Auto-generated method stub
		return repo.findById(userId).orElse(new User());
	}

	@Override
	public UserDepartmentVO getUserWithDept(Long userId) {
		// TODO Auto-generated method stub
		User user = getUserById(userId);
		user.getDepartmentId();
		return null;
	}

}
