package com.training.usermicroservice.vo;

import com.training.usermicroservice.entity.User;

public class UserDepartmentVO {

	private User user;
	private Department depart;
	public UserDepartmentVO(User user, Department depart) {
		super();
		this.user = user;
		this.depart = depart;
	}
	public UserDepartmentVO() {
		super();
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Department getDepart() {
		return depart;
	}
	public void setDepart(Department depart) {
		this.depart = depart;
	}
	
}
