package com.starhealth.springrestapi.controller;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.util.List;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.web.client.RestTemplate;

import com.starhealth.springrestapi.entity.Employee;

import lombok.extern.slf4j.Slf4j;


@Slf4j
@SpringBootTest
class EmployeeRestControllerTest {

		@Autowired
		RestTemplate restTemplate;
	
	
	@Test
	void testaddEmployee() {
		
		Employee emp1 = new Employee();
		
			emp1.setEname("Tommy");
			emp1.setEid(345);
			emp1.setSalary(45000);
			
		
	Employee empTest =	restTemplate.postForObject("http://localhost:8282/api/v1/employees/add", emp1, Employee.class);
		
		assertNotNull(empTest);
	
	}

	@Test
	void testGetEmployeeById() {
		
		long employeeId = 345;
		
	Employee empTest =	restTemplate.getForObject("http://localhost:8282/api/v1/employees/get/"+employeeId, Employee.class);
		
		
	
		assertNotNull(empTest);
	
		
	}
	
	@Test
	void testupdateEmployee() {
		
		long employeeId = 345;
		Employee emp1 = new Employee();
		emp1.setEid(345);
		emp1.setEname("Tommy");
		emp1.setSalary(50000);
		
	Employee empTest =	restTemplate.patchForObject("http://localhost:8282/api/v1/employees/update",emp1, Employee.class);
		
		
	
		assertNotNull(empTest);
	
		
	}
	
	@Test
	void testdeleteEmployeeById() {
		
		long employeeId = 345;
		assertNotNull(restTemplate.delete("http://localhost:8282/api/v1/employees/delete/"+employeeId, Employee.class));
		
	}

}
