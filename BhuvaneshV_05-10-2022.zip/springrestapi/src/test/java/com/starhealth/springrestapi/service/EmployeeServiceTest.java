package com.starhealth.springrestapi.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.starhealth.springrestapi.entity.Employee;
import com.starhealth.springrestapi.service.IEmployeeService;

@SpringBootTest
public class EmployeeServiceTest {

	@Autowired
	IEmployeeService service;
	
	@Test
	public void  addEmployee() {
		Employee emp1 = new Employee();
		emp1.setEid(234);
		emp1.setEname("Ash");
		emp1.setSalary(30000);
		
		Employee empTest = service.addEmployee(emp1);
		assertEquals("Ash", empTest.getEname());
	}
	
	@Test
	public void  updateEmployee() {
		Employee emp1 = new Employee();
		emp1.setEid(234);
		emp1.setEname("Ashwin");
		emp1.setSalary(35000);
		Employee empTest = service.updateEmployee(emp1);
		assertEquals("Ashwin", empTest.getEname());
	}
	
	@Test
	public void selectEmployeeById() {
		Employee empTest = service.selectEmployeeById(234);
		assertEquals("Ashwin", empTest.getEname());
	}
	
}
