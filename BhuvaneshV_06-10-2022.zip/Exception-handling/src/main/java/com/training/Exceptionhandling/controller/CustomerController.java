package com.training.Exceptionhandling.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.training.Exceptionhandling.dto.customer;

@RestController
@RequestMapping("/api")
public class CustomerController {
	
	@GetMapping("/get")
	public String get() {
		String msg = null;
		return msg;
	}

	public customer addCustomer(@RequestBody customer cust) {
	
		System.out.println(cust);
		return cust;
	}
	
	@ExceptionHandler(value = NullPointerException.class)
	@ResponseStatus(code = HttpStatus.BAD_REQUEST, reason = "Null value occur")
	public void exceptionHandler() {
		
	}
	
	@ExceptionHandler(value = ArithmeticException.class)
	public ResponseEntity<String> exceptionHandler2(){
		return new ResponseEntity<String>("Sorry number can't be div by zero",HttpStatus.BAD_REQUEST);
	}
}

