package com.training.Exceptionhandling.dto;

public class customer {
	
	private long cid;
	private String cname;
	private long mo;
	private String email;
	public long getCid() {
		return cid;
	}
	public void setCid(long cid) {
		this.cid = cid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public long getMo() {
		return mo;
	}
	public void setMo(long mo) {
		this.mo = mo;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public customer(long cid, String cname, long mo, String email) {
		super();
		this.cid = cid;
		this.cname = cname;
		this.mo = mo;
		this.email = email;
	}
	public customer() {
		super();
	}
}
