function f(){
    alert("Button pressed")
    var element = document.getElementById("uid")
    alert(element)
    console.log(element)
    var uname = element.value;
    alert(uname)
}