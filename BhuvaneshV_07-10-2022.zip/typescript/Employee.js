var Employee = /** @class */ (function () {
    function Employee() {
        console.log("constructor called");
    }
    Employee.prototype.m1 = function () {
        console.log("method m1 called");
    };
    return Employee;
}());
var e1 = new Employee();
console.log(e1);
