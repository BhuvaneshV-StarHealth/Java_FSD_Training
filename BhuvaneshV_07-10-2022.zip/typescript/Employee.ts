class Employee{
    constructor(){
        console.log("constructor called")
    }

    m1(){
        console.log("method m1 called")
    }
}

var e1 = new Employee()
console.log(e1)