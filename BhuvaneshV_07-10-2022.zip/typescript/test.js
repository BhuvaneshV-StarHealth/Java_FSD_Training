function fun(){
    let name="arun"
    console.log(name)
}

fun()

//anonymous function

var f2=function(name){
    return "welcome "+name;
}

console.log(f2("arun"))

//arrow function
var f3=(eid,ename) => {
    console.log(eid +" "+ename);
}

f3(101,"arun")

//default parameter

function add(a,b=2){
    return a+b
}
console.log(add(3))

//spread or rest parameter
//spread or rest parameter is right to left assosciative

function sub(...a){ //a[]
    console.log("spread func called")
}

function sub1(name,...a){
    console.log("multiple spread parameters")
}

sub(1,2,3,4)
sub1("arun",1,2,3,4)

function stringDemo(){
    let str1 = "hello friends \n how are you?"
    console.log(str1)

    //backtick string template
    let str2 = `hello friends
    how are you?`
    console.log(str2)

    salary=30000
    //string niterpolation - ${} = {{}}
    let str3 = `my salary is ${salary}`
    console.log(str3)
}

stringDemo()
