function myfun(){
    let x = 100;
    const y = 200;

    console.log(x);
    console.log(y);
}