package com.training.datatypes.exercise;

public class Exercise {
	
	private int exe_no;
	String exe_name;
	static String  exe_chapter;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Call from static to non static");
		Exercise  e1 =	new  Exercise();
		System.out.println(e1.exe_no);
		System.out.println(e1.exe_name);
		
		System.out.println("Call from static to static");
		System.out.println(exe_chapter);
		
		System.out.println("Call from static to non static");
		e1.display();
		
		System.out.println("Call from static to static");
		get();
	}
	
	public void display() {
		System.out.println("welcome to non static method display()");
		System.out.println(exe_no);
		System.out.println(exe_name);
	}

	public static void get() {
		System.out.println("Hi am static method get()");
	}
}
