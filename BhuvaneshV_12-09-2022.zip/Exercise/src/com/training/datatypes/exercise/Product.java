package com.training.datatypes.exercise;

public class Product {

	int pid;
	String pname;
	String pcategory;
	double prate;
	
	public int getPid() {
		return pid;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public String getPcategory() {
		return pcategory;
	}

	public void setPcategory(String pcategory) {
		this.pcategory = pcategory;
	}

	public double getPrate() {
		return prate;
	}

	public void setPrate(double prate) {
		this.prate = prate;
	}

	public Product(int pid, String pname, String pcategory, double prate) {
		super();
		this.pid = pid;
		this.pname = pname;
		this.pcategory = pcategory;
		this.prate = prate;
	}

	@Override
	public String toString() {
		return "Product [pid=" + pid + ", pname=" + pname + ", pcategory=" + pcategory + ", prate=" + prate + "]";
	}
}
