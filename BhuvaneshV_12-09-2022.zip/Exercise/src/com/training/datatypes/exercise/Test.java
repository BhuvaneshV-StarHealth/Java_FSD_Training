package com.training.datatypes.exercise;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Product p1 = new Product(1,"Brush","HomeNeeds",12.50);
		Product p2 = new Product(2,"Toothpaste","HomeNeeds",15.50);
		
		System.out.println(p1.toString());
		System.out.println(p2.toString());
		
		p1.setPid(12);
		p2.setPid(13);
		System.out.println(p1.toString());
		System.out.println(p2.toString());
		
	}

}
