package com.starhealth.oops.Inheritance;

public class Child extends Parent {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Parent c = new Parent();
		c.info();
		Child ob = new Child();
		System.out.println("parent to parent access to properties" + c.toString());
		c.info();
		ob.display();
	}
	public void   display(){
		System.out.println("dispaly method inheritance by Child Class"); 
	}
}
