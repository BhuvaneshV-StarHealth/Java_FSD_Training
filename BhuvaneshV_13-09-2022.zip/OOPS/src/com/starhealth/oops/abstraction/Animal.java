package com.starhealth.oops.abstraction;

public abstract class Animal {
	
	public abstract void animalSound();
	
	
	   public void sleep() {
	    System.out.println("sleeping");
	  }
	  
}
