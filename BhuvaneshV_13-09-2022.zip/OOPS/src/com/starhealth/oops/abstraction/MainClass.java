package com.starhealth.oops.abstraction;

public class MainClass {
		  public static void main(String[] args) {
		    Subclass obj = new Subclass(); 
		    obj.animalSound();
		    obj.sleep();
		  }
		

}
