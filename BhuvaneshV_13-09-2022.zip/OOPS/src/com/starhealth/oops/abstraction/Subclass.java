package com.starhealth.oops.abstraction;

class Subclass extends Animal {
	
	
	  public void animalSound() {
	    
	    System.out.println("roar roar");
	  }
	}