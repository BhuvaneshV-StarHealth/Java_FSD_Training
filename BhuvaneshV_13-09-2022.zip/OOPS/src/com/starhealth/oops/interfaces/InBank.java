package com.starhealth.oops.interfaces;

public interface InBank {
	public abstract  void print(); 

	
	public abstract  void deposite(); 
}
