package com.starhealth.oops.polymorphism;

public class Animal {
	
	public void eat() {
		System.out.println("Eating");
	}
	public void display() {
		System.out.println("Annimals class print display() method");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Animal a = new Animal();
		a.eat();
		Animal a1 = new Bear();
		a1.eat();

	}

}
