package com.starhealth.oops.polymorphism;

public class Bear  extends Animal{
	public void eat() {
		System.out.println("eating salmon");
	
	}
	@Override
	public void display() {
		System.out.println("Bear class print display() method by override");
	}
	
	public static void sum() {
		System.out.println("default sum() method");
	}
	public static void sum(int a,int b) {
		System.out.println(a+b);
	}
	public static void sum(int a,int b, int c) {
		System.out.println(a+b + c);
	}
	
	public  static void main(String[] args) {
//		method overloading
		sum(2,3);
		sum(2,3, 3);
		
		
	}

}
