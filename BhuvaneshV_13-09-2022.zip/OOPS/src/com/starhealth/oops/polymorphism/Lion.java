package com.starhealth.oops.polymorphism;

public class Lion {
	
	public void eat() {
		System.out.println("eating meat");
	}
	
	public static void main(String[] args) {
		
		Animal obj1 = new Bear();
		obj1.display();
		
		Animal obj2 = new Animal();
		obj2.display();
	}

}
