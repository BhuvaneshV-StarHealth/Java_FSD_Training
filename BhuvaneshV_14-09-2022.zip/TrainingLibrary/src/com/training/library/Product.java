package com.training.library;

public class Product {
	private String pName;
	private int pId;
	private String pCategory;
	private double pRate;
	
	public Product() {
		super();
	}
	public Product(String pName, int pId, String pCategory, double pRate) {
		super();
		this.pName = pName;
		this.pId = pId;
		this.pCategory = pCategory;
		this.pRate = pRate;
	}
	public String getpName() {
		return pName;
	}
	public void setpName(String pName) {
		this.pName = pName;
	}
	public int getpId() {
		return pId;
	}
	public void setpId(int pId) {
		this.pId = pId;
	}
	public String getpCategory() {
		return pCategory;
	}
	public void setpCategory(String pCategory) {
		this.pCategory = pCategory;
	}
	public double getpRate() {
		return pRate;
	}
	public void setpRate(float pRate) {
		this.pRate = pRate;
	}
	@Override
	public String toString() {
		return "Product Entity [pName=" + pName + ", pId=" + pId + ", pCategory=" + pCategory + ", pRate=" + pRate + "]";
	}
}
