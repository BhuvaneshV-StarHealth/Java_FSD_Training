package com.training.library;

public class ProductList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Product p1 = new Product("Atta flour",101,"Cooking",120.0);
		Product p2 = new Product("Television",221,"Home Appliances",120000.0);
		
		System.out.println(p1);
		System.out.println(p2);
		
		System.out.println("p1 Hashcode( )" + p1.hashCode());
		System.out.println("p2 Hashcode( )" + p1.hashCode());
		System.out.println("Equality check : " + p1.equals(p2));
		System.out.println(p1 == p2);

	}
	
	

}
