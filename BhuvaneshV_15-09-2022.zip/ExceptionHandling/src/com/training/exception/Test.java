package com.training.exception;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		long[]userPinCode = {601003,756123,980453,234098,309675};
		long[]acceptedPinCode = {980453,309675,756123};
		int userPinCodeLen = userPinCode.length;
		int acceptedPinCodeLen = acceptedPinCode.length;
		for(int i=0;i<userPinCodeLen;i++) {
			int flag = 0;
			for(int j=0;j<acceptedPinCodeLen;j++) {
				if (userPinCode[i]==acceptedPinCode[j]) {
					flag=1;
					break;
				}
			}
			if (flag==0) {
				try {
					throw new atmPinException("Invalid ATM Pin "+userPinCode[i]);
				}
				catch(Exception e) {
					System.err.println(e);
				}
			}
			else {
				System.out.println("ATM Pin "+userPinCode[i]+" accepted.");
			}
		}
	}
}
