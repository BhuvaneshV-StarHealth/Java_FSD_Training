package com.training.exception;

public class atmPinException extends Exception {

	public atmPinException(String error){
		super(error);
	}
}
