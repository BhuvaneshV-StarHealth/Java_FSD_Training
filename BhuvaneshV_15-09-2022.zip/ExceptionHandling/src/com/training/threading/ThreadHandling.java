package com.training.threading;

public class ThreadHandling extends Thread {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ThreadHandling t1 = new ThreadHandling();
		t1.setName("Thread 1");
		t1.start();
		
		ThreadHandling t2 = new ThreadHandling();
		t2.setName("Thread 2");
		t2.start();
		
	}
	
	@Override
	public void run() {
		for(int i=0;i<10;i++) {
			System.out.println(Thread.currentThread().getName());
		}
	}

}
