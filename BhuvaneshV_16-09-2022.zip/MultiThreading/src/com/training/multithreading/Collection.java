package com.training.multithreading;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class Collection {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Object> list  = new ArrayList<Object>();
		list.add("A");
		list.add("B");
		list.add("C");
		list.add("D");
		System.out.println(list);
		System.out.println("Size of list: " + list.size());
		System.out.println("Removing last index....");
		list.remove(3);
		System.out.println("List:" + list);
		Iterator<Object> it = list.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
		List<Object> linkedlist = new LinkedList<Object>();
		linkedlist.add("apple");
		linkedlist.add(1);
		linkedlist.add(1.12);
		linkedlist.add(1,"banana");
		System.out.println(linkedlist);
		System.out.println(linkedlist.get(3));
	}

}
