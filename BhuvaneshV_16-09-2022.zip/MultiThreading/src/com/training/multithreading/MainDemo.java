package com.training.multithreading;

public class MainDemo {

	public static void main(String argvs[]) {

		ThreadDemo th1 = new ThreadDemo();
		ThreadDemo th2 = new ThreadDemo();
		ThreadDemo th3 = new ThreadDemo();

		th1.start();

		try {
			System.out.println("The current thread: " + Thread.currentThread().getName());

			th1.join();
		}

		catch (Exception e) {
			System.out.println("The exception has been caught " + e);
		}

		th2.start();

		try {
			System.out.println("The current thread name is: " + Thread.currentThread().getName());
			th2.join();
		}

		catch (Exception e) {
			System.out.println("The exception has been caught " + e);
		}

		th3.start();
	}
}