package com.java8;

@FunctionalInterface
public interface InterfaceDemo {

	public abstract int  add(int a, int b);
	
//	void m(String s);
	
	
}
