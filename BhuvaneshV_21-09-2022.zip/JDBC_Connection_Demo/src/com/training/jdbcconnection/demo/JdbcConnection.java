package com.training.jdbcconnection.demo;

import java.sql.DriverManager;

public class JdbcConnection {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Connection conn = null;
		try {
			DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbc_demo", "root", "root");
			Statement st = conn.createStatement();
			String query = "select * from starhealth";
			ResultSet rs = st.executeQuery(query);
			while (rs.next()) {
				String name = rs.getString("insurance_product");
				int cost = rs.getInt("premium");
				System.out.println(name + " = " + cost );
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}	
		finally {
			try {
				conn.close();
			} catch (Exception e2) {
				// TODO: handle exception
			}
		}
	}

}
