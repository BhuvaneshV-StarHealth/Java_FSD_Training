package com.training.jdbcconnection.demo;

public class JdbcConnectionNonSelect {
	Connection conn = null;
	try {
		DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
		conn =	DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbc_demo", "root", "root");
		Statement smt = conn.createStatement();
		String query = "insert into starhealth values(101,'child_care',467),"
			+ " (102,'family_care',987) ";   //INSERT
		/*
		 * String query =
		 * "update product_list set insurance_name = 'youth_care' where insurance_id = 101"; //UPDATE
		 */
		/* String query = "delete from starhealth where premium > 500"; */ //DELETE
		int count = smt.executeUpdate(query);
		System.out.println(count);
	} catch (SQLException e) {
		e.printStackTrace();
	}
	finally {
		try {	
			c.close();
		} catch (Exception e2) {
			// TODO: handle exception
		}
	}
}
