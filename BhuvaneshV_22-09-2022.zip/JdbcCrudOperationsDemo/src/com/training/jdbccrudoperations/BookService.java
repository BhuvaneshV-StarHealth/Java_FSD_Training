package com.training.jdbccrudoperations;

public class BookService {

	public boolean validateInputs(Books emp) {

		boolean isValid = false;

		if (emp.getBid() > 99 && emp.getBname().length() > 3 && emp.getBprice() > 1000) {

			isValid = true;
		}

		return isValid;

	}

}
