package com.training.layeredarchitecture.dao;

import com.training.layeredarchitecture.bean.Product;

public interface IProductDAO {
	public int addProduct(Product p);
	public int updateProduct(Product p);

}
