package com.training.layeredarchitecture.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.training.layeredarchitecture.bean.Product;

public class ProductDaoImp implements IProductDAO {

	Connection conn = DBUtil.getDBConnection();

	@Override
	public int addProduct(Product p) {
		// TODO Auto-generated method stub
		int count = 0;
		try {

			String insertQuery = "insert into product(pid,product_name,product_price,product_category) values(?,?,?,?)";
			PreparedStatement pstmt = conn.prepareStatement(insertQuery);

			pstmt.setInt(1, p.getpId());
			pstmt.setString(2, p.getpName());
			pstmt.setDouble(3, p.getpPrice());
			pstmt.setString(4, p.getpCategory());

			count = pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return count;
	}

	@Override
	public int updateProduct(Product p) {
		// TODO Auto-generated method stub
		int count = 0;
		String updateQuery = "update product set product_name=?,product_price=?,product_category=? where pid=?";
		try {
			PreparedStatement pstmt = conn.prepareStatement(updateQuery);
			pstmt.setString(1, p.getpName());
			pstmt.setDouble(2, p.getpPrice());
			pstmt.setString(3, p.getpCategory());
			pstmt.setInt(4, p.getpId());
			count = pstmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return count;
	}

}
