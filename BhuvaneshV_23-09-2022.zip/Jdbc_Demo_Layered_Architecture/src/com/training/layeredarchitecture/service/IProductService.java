package com.training.layeredarchitecture.service;

import com.training.layeredarchitecture.bean.Product;

public interface IProductService {
	
	public int addProduct(Product p);
	public int updateProduct(Product p);

}
