package com.training.layeredarchitecture.service;

import com.training.layeredarchitecture.bean.Product;
import com.training.layeredarchitecture.dao.IProductDAO;
import com.training.layeredarchitecture.dao.ProductDaoImp;

public class ProductServiceImp implements IProductService {

	IProductDAO dao = new ProductDaoImp();

	@Override
	public int addProduct(Product p) {
		// TODO Auto-generated method stub
		return dao.addProduct(p);
	}

	@Override
	public int updateProduct(Product p) {
		// TODO Auto-generated method stub
		return dao.updateProduct(p);
	}

	public static boolean validateInputs(Product p) {
		boolean isValid = false;
		if (p.getpId() > 99 && p.getpName().length() > 3 && p.getpCategory().length() >= 4) {
			isValid = true;
		}
		return isValid;
	}
}
