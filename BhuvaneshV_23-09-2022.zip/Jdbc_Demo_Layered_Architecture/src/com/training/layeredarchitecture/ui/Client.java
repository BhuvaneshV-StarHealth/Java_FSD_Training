package com.training.layeredarchitecture.ui;

import java.util.Scanner;
import com.training.layeredarchitecture.bean.Product;
import com.training.layeredarchitecture.service.IProductService;
import com.training.layeredarchitecture.service.ProductServiceImp;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		IProductService service = new ProductServiceImp();

		boolean flag = true;

		while (flag) {

			System.out.println("*******WELCOME TO PRODUCT MANAGEMENT SYSTEM*******");
			System.out.println("1. Add Product");
			System.out.println("2. Update Product");
			/*
			 * System.out.println("3. Delete Product By Id");
			 * System.out.println("4. Select Product By Id");
			 * System.out.println("5. Select All Products");
			 */
			System.out.println("3. Logout/Exit");

			int choice = scanner.nextInt();

			switch (choice) {
			case 1:

				Product p = inputData();

				boolean isValid = ProductServiceImp.validateInputs(p);

				if (isValid) {
					int count = service.addProduct(p);

					System.out.println(count + " record inserted successfully");
				} else {

					System.err.println("Please Enter valid Inputs");

				}
				break;

			case 2:

				Product p1 = inputData();

				// update from DAO class

				int updateCount = service.updateProduct(p1);

				System.out.println(updateCount + " record updated successfully");

				break;

			/*
			 * case 3:
			 * 
			 * System.out.println("Enter Id to Delete One Record"); int deleteId =
			 * scanner.nextInt();
			 * 
			 * int deleteCount = service.deleteEmployeeById(deleteId);
			 * 
			 * System.out.println(deleteCount + " record deleted successfully");
			 * 
			 * break;
			 * 
			 * case 4: System.out.println("Enter Id to Select One Record"); int searchId =
			 * scanner.nextInt();
			 * 
			 * Employee emp1 = service.selectEmployeeById(searchId);
			 * 
			 * System.out.println(emp1);
			 * 
			 * break;
			 * 
			 * case 5:
			 * 
			 * // select all
			 * 
			 * List<Employee> list = service.selectAllEmployeees();
			 * 
			 * Stream<Employee> stream = list.stream();
			 * 
			 * // stream.forEach((Employee e1)-> {System.out.println(e1);});
			 * 
			 * stream.forEach(System.out::println);
			 * 
			 * break;
			 */
			case 3:

				// System.exit(0);// killing JVM

				System.out.println("Thank You , Logout Success");

				flag = false;

				break;

			default:
				break;
			}
		}

	}

	public static Product inputData() {

		Scanner scanner = new Scanner(System.in);

		System.out.println("Enter product ID:");
		int pid = scanner.nextInt();
		System.out.println("Enter product name:");
		String pname = scanner.next();
		System.out.println("Enter product price:");
		double ppice = scanner.nextDouble();
		System.out.println("Enter product category:");
		String pcategory = scanner.next();

		Product p = new Product();
		p.setpId(pid);
		p.setpName(pname);
		p.setpPrice(ppice);
		p.setpCategory(pcategory);
		return p;

	}
}
