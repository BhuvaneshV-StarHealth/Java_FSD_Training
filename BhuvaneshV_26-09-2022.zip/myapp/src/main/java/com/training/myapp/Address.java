package com.training.myapp;

public class Address {
	
	private int doorno;
	private String addr;
	public int getDoorno() {
		return doorno;
	}
	public void setDoorno(int doorno) {
		this.doorno = doorno;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public Address(int doorno, String addr) {
		super();
		this.doorno = doorno;
		this.addr = addr;
	}
	public Address() {
		super();
	}
	@Override
	public String toString() {
		return "Address [doorno=" + doorno + ", addr=" + addr + "]";
	}
	

}
