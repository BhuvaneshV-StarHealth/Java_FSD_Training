package com.training.springannotationsdemo.controller;

import org.springframework.stereotype.Controller;

@Controller
public class HelloController {

}
