package com.training.springannotationsdemo.dao;

public interface ICustomerRepository {
	
	public void   getRepo();

}
