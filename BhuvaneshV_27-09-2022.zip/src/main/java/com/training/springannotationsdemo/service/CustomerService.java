package com.training.springannotationsdemo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.starhealth.springannotations.dao.EmployeeRepositoryImp;
import com.starhealth.springannotations.dao.IEmployeeRepository;

@Service
public class CustomerService  implements ICustomerService {

	
	@Autowired
	ICustomerRepository repo;
	
	
	@Override
	public void callService() {


		System.out.println(" Service method is called");
		System.out.println("service getting repo obj "+repo);
		
	}

}
