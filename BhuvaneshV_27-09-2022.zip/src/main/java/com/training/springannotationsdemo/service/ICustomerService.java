package com.training.springannotationsdemo.service;

public interface ICustomerService {
	
	
	public void  callService();

}
