package com.training.springmvc.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.training.springmvc.entity.Product;
import com.training.springmvc.service.IProductService;

@Controller
@RequestMapping("/api/v1/products")
public class ProductController {

	// Request Handler

	// @RequestMapping(value="/add",method = RequestMethod.POST)
	// @ResponseBody
	/*
	 * public String addEmployee(HttpServletRequest request,HttpServletResponse
	 * response,HttpSession session) {
	 * 
	 * 
	 * // logic to get data from html form
	 * 
	 * String eid = request.getParameter("eid"); String ename =
	 * request.getParameter("ename"); String salary =
	 * request.getParameter("salary");
	 * 
	 * 
	 * return eid +" "+ename+" "+salary;
	 * 
	 * }
	 */

	/*
	 * @RequestMapping(value="/add",method = RequestMethod.POST)
	 * 
	 * @ResponseBody public String add(Employee employee) {
	 * 
	 * System.out.println(employee);
	 * 
	 * 
	 * return employee.toString();
	 * 
	 * }
	 */

	
		@Autowired
		IProductService service;
	
	@RequestMapping(value = "/add", method = RequestMethod.POST)
	@ResponseBody
	public String add(Product p) {

		System.out.println(p);
		
		int count  = service.addProduct(p);

		return  count+ " Record Added Successfully";

	}

	
	@RequestMapping("/getall")
	@ResponseBody
	public  String  getAllEmployees(HttpSession session) {
		
		
	List<Product>  list =	service.selectAllProducts();
		
		System.out.println(list);
		
		session.setAttribute("productList", list);
		
		return "success";
	}
	
	
	
}
