package com.training.springmvc.repository;

import java.util.List;

import com.training.springmvc.entity.Product;

public interface IProductDAO {
	
	
	
	public int  addProduct(Product emp);
	
	
	public List<Product>  selectAllProducts();
	
	

}
