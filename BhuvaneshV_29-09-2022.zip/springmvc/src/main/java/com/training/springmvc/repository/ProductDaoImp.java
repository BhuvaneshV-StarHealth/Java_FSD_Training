package com.training.springmvc.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.training.springmvc.entity.Product;

@Repository
public class ProductDaoImp implements IProductDAO {

	Connection conn = DBUtil.getDBConnection();
	
	@Override
	public int addProduct(Product p) {
		
		int count = 0;

		try {
			String insertQuery = "insert into product(pid,product_name,product_price,product_category) values(?,?,?,?)";
			PreparedStatement pstmt = conn.prepareStatement(insertQuery);

			pstmt.setInt(1, p.getPid());
			pstmt.setString(2, p.getPname());
			pstmt.setDouble(3, p.getPrice());
			pstmt.setString(4, p.getPcategory());

			count = pstmt.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return count;
		
		
	}

	

	@Override
	public List<Product> selectAllProducts() {
		String selectQuery = "select * from product;";

		PreparedStatement pstmt;

		List<Product> list = new ArrayList<Product>();
		
		try {
			pstmt = conn.prepareStatement(selectQuery);

			ResultSet rs = pstmt.executeQuery();

			

			while (rs.next()) {

				Product p1 = new Product();
				p1.setPid(rs.getInt("pid"));
				p1.setPname(rs.getString("product_name"));
				p1.setPrice(rs.getDouble("product_price"));
				p1.setPcategory(rs.getString("product_category"));

				list.add(p1);

			}

		} catch (SQLException e) {

			e.printStackTrace();
		}

		return list;
	}

}
