package com.training.springmvc.service;

import java.util.List;

import com.training.springmvc.entity.Product;

public interface IProductService {
	
	
	
	public int  addProduct(Product emp); //post
	
	
	public List<Product>  selectAllProducts(); //get 
	
	

}
