package com.training.springmvc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.springmvc.entity.Product;
import com.training.springmvc.repository.IProductDAO;
@Service
public class ProductServiceImp implements IProductService {

	@Autowired
	IProductDAO  dao ;
	
	
	@Override
	public int addProduct(Product p) {
		
		return  dao.addProduct(p);
	}

	

	@Override
	public List<Product> selectAllProducts() {
		
		return dao.selectAllProducts();
	}

	
	
	
	
	
	
}
