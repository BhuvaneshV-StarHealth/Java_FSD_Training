import { Component, OnInit } from '@angular/core';
import { ProductService } from './product.service';

@Component({
  selector: 'app-product',
  //template: '<h1>Welcome to product component</h1>'
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  pid = 101
  pname = 'Biscuits'
  price = 20
  url:string = "assets/biscuits.jfif"
  constructor(private service:ProductService) { 
    console.log('ProductComponenet obj created...')
  }

  ngOnInit(): void {
  }

  test():void{
    this.service.myservice()
  }

  hello():void{
    alert("Event binding")
  }

}
