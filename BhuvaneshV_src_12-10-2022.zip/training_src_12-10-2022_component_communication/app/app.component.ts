import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'training_12_10_2022';
  choice:string = "e"
  course:string = "r";
  names:string[] = ["aram","bam","ram","arun","varun"]
}
