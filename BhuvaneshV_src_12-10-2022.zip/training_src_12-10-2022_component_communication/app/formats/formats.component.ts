import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-formats',
  templateUrl: './formats.component.html',
  styleUrls: ['./formats.component.css']
})
export class FormatsComponent implements OnInit {

  amount:number = 20000
  date:Date = new Date();
  pi:number = 3.14
  constructor() { }

  ngOnInit(): void {
  }

}
