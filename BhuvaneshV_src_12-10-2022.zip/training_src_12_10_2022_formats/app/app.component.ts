import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'training_12_10_2022';
  parentData = "This is parent data"
  dataFromChild:string = ""

  getData(data:any){
    console.log(data);
    this.dataFromChild = data
  }
}
